#' Insert >>> TITLE <<< here ...
#'
#' Insert (longer) >>> DESCRIPTION <<< here ...
#'
#' @param alpha <description of alpha>
#' @param beta  <description of beta>
#'
#' @return describe what the function is giving back to the user (insert "None" if there's no value returned)
#'
#' @author Luca Valnegri, \email{l.valnegri@datamaps.co.uk}
#' @references data wrangling, shiny apps
#' @seealso \code{\link{...}}
#'
#' @keywords
#'
#' @examples
#' my_function(alpha = , beta = )
#'
#' @import pkgname ...
#'
#' @importFrom pkgname funname ...
#'
#' @export
#' 
#' \dontrun{
#'     example code
#' }
#'
my_function <- function(alpha, beta){

    # oopt <- options( list the options you change )
    # on.exit(options(oopt), add = TRUE)
    # opar <- par( list the parameters you change )
    # on.exit(options(opar), add = TRUE)
    # tmpf <- tempfile()
    # tmpd <- tempdir()
    # on.exit(unlink(c(tmpf, tmpd)), add = TRUE)
    
    # ...code...
    
    

}
