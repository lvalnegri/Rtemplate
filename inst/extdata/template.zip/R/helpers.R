# short internal (not exported) functions used only by other exported functions

fun_name <- function(x, y){
  
}
