#' pkgname
#' 
#' Insert a thorough description of what the package is expected to do 
#'  
#' @docType package
#' @name pkgname
NULL
