#' Insert >>> TITLE <<< here ...
#'
#' @param alpha <description of alpha>
#' @param beta  <description of beta>
#'
#' @return describe what the function is giving back to the user (insert "None" if there's no value returned)
#'
#' @author Luca Valnegri, \email{l.valnegri@datamaps.co.uk}
#'
#' @import data.table
#'
#' @export
#'
fun_name <- function(alpha, beta){
  
}
