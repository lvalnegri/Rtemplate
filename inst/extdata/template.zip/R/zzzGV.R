utils::globalVariables(c(
    'id', 'x_lon', 'y_lat' # column names in data.table "table_name" 
))
