# library(testthat)
# library(pkgname)
# 
# test_check('pkgname')
