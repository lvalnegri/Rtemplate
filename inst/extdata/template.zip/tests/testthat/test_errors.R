# test_that(' describe the kind of general error you are testing', {
#   
#     expect_that(
#       # wrong call to a function
#       throws_error('explain the specific error')
#     )
#   
# })
#   
